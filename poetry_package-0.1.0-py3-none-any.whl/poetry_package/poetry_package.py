
def hello():
    text = "Hello from package"
    print(text)
    return text